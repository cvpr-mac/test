import torch
import torch.nn as nn
from torch.nn import Parameter
import torch.nn.functional as F
from torch.autograd import Variable
import functools

class ConvLSTMCell(nn.Module):


    def __init__(self, input_size, hidden_size):
        super(ConvLSTMCell,self).__init__()
        self.KERNEL_SIZE = 3
        self.PADDING = self.KERNEL_SIZE // 2
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.in_gate = nn.Conv2d(input_size + hidden_size, hidden_size, self.KERNEL_SIZE, padding=self.PADDING)
        self.remember_gate = nn.Conv2d(input_size + hidden_size, hidden_size, self.KERNEL_SIZE, padding=self.PADDING)
        self.out_gate = nn.Conv2d(input_size + hidden_size, hidden_size, self.KERNEL_SIZE, padding=self.PADDING)
        self.cell_gate = nn.Conv2d(input_size + hidden_size, hidden_size, self.KERNEL_SIZE, padding=self.PADDING)

    def forward(self, input_, prev_state):

        batch_size = input_.data.size()[0]
        spatial_size = input_.data.size()[2:]

        # generate empty prev_state, if None is provided
        if prev_state is None:
            state_size = [batch_size, self.hidden_size] + list(spatial_size)
            prev_state = (
                Variable(torch.zeros(state_size)).cuda(),
                Variable(torch.zeros(state_size)).cuda()
            )

        prev_hidden, prev_cell = prev_state

        # data size is [batch, channel, height, width]
        stacked_inputs = torch.cat((input_, prev_hidden), 1)
        in_gate = torch.sigmoid(self.in_gate(stacked_inputs))
        remember_gate =torch.sigmoid(self.remember_gate(stacked_inputs))
        out_gate = torch.sigmoid(self.out_gate(stacked_inputs))
        cell_gate = torch.tanh(self.cell_gate(stacked_inputs))

        # compute current cell and hidden state
        cell = (remember_gate * prev_cell) + (in_gate * cell_gate)
        hidden = out_gate * torch.tanh(cell)
        return hidden, cell

class stochastic(nn.Module):
    def __init__(self, input_size, hidden_size,output_size,n_layers,batch_size, type ='lstm', wh = 8):
        super(stochastic, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.batch_size = batch_size
        self.n_layers = n_layers
        self.wh = wh
        self.type = type
        if self.type == 'lstm':
            self.convlstm = nn.ModuleList([ConvLSTMCell(input_size, hidden_size) if i==0 else ConvLSTMCell(hidden_size, hidden_size) for i in range(self.n_layers)])


        self.mu = nn.Conv2d(hidden_size, output_size, 3, 1, 1)
        self.logvar = nn.Conv2d(hidden_size, output_size, 3, 1, 1)
        self.hidden = self.init_hidden()

    def init_hidden(self):
        hidden = []
        for i in range(self.n_layers):
            hidden.append((Variable(torch.zeros(self.batch_size, self.hidden_size,self.wh,self.wh).cuda()),
                           Variable(torch.zeros(self.batch_size, self.hidden_size,self.wh,self.wh).cuda())))
        return hidden

    def reparameterize(self, mu, logvar):
        logvar = logvar.mul(0.5).exp_()
        eps = Variable(logvar.data.new(logvar.size()).normal_())
        return eps.mul(logvar).add_(mu)

    def forward(self, input):
        h_in = input
        for i in range(self.n_layers):
            self.hidden[i] = self.convlstm[i](h_in,self.hidden[i])
            h_in = self.hidden[i][0]
        mu = self.mu(h_in)
        logvar = self.logvar(h_in)
        z = self.reparameterize(mu, logvar)
        return z, mu, logvar


class predictor(nn.Module):
    def __init__(self, input_size, hidden_size,output_size,n_layers,batch_size,type ='lstm', wh = 8):
        super(predictor, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.n_layers = n_layers
        self.batch_size = batch_size
        self.wh = wh
        self.type = type
        if self.type == 'lstm':
            self.convlstm = nn.ModuleList([ConvLSTMCell(input_size, hidden_size) if i==0 else ConvLSTMCell(hidden_size, hidden_size) for i in range(self.n_layers)])

        # self.output = nn.Sequential(
        #     nn.Conv2d(hidden_size, output_size,3,1,1),
        #     nn.Tanh())
        self.hidden = self.init_hidden()

    def init_hidden(self):
        hidden = []
        for i in range(self.n_layers):
            hidden.append((Variable(torch.zeros(self.batch_size, self.hidden_size,self.wh,self.wh).cuda()),
                           Variable(torch.zeros(self.batch_size, self.hidden_size,self.wh,self.wh).cuda())))
        return hidden

    def forward(self, input,z):
        h_in = input
        for i in range(self.n_layers):
            self.hidden[i] = self.convlstm[i](h_in,self.hidden[i])
            h_in += self.hidden[i][0]
        return h_in[:,:self.output_size]