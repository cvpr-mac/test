import torch
import torch.nn as nn
from torch.nn import Parameter
import torch.nn.functional as F
from torch.autograd import Variable
import functools

class word_capsule(nn.Module):
    def __init__(self, input_size, output_size):
        super(word_capsule, self).__init__()
        self.input_size = input_size
        self.output_size = output_size
        self.model = nn.Sequential(nn.Conv2d(self.input_size, self.output_size, 3, 1, 1),
                                                nn.InstanceNorm2d(self.output_size, affine=True),
                                                nn.ReLU(),
                                                nn.Conv2d(self.output_size, self.output_size, 3, 1, 1))
    def forward(self, input):
        return self.model(input)