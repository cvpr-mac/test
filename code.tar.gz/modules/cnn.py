import torch
import torch.nn as nn
from torch.nn import Parameter
import torch.nn.functional as F
from torch.autograd import Variable
import functools



def split(x):
    n = int(x.size()[1]/2)
    x1 = x[:, :n, :, :].contiguous()
    x2 = x[:, n:, :, :].contiguous()
    return x1, x2


def merge(x1, x2):
    return torch.cat((x1, x2), 1)


class injective_pad(nn.Module):
    def __init__(self, pad_size):
        super(injective_pad, self).__init__()
        self.pad_size = pad_size
        self.pad = nn.ZeroPad2d((0, 0, 0, pad_size))

    def forward(self, x):
        x = x.permute(0, 2, 1, 3)
        x = self.pad(x)
        return x.permute(0, 2, 1, 3)

    def inverse(self, x):
        l = len(x[1])
        return x[:, :l-self.pad_size, :, :]




class psi(nn.Module):
    def __init__(self, block_size):
        super(psi, self).__init__()
        self.block_size = block_size
        self.block_size_sq = block_size*block_size

    def inverse(self, inpt):
        bl, bl_sq = self.block_size, self.block_size_sq
        bs, d, h, w = inpt.shape
        return inpt.view(bs, bl, bl, int(d // bl_sq), h, w).permute(0, 3, 4, 1, 5, 2).reshape(bs, -1, h * bl, w * bl)

    def forward(self, inpt):
        bl, bl_sq = self.block_size, self.block_size_sq
        bs, d, new_h, new_w = inpt.shape[0], inpt.shape[1], int(inpt.shape[2] // bl), int(inpt.shape[3] // bl)
        return inpt.view(bs, d, new_h, bl, new_w, bl).permute(0, 3, 5, 1, 2, 4).reshape(bs, d * bl_sq, new_h, new_w)

class irevnet_block(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1, first=False, dropout_rate=0.,
                 affineBN=True, mult=4):
        """ buid invertible bottleneck block """
        super(irevnet_block, self).__init__()
        self.first = first
        self.stride = stride
        self.psi = psi(stride)
        layers = []
        if not first:
            layers.append(nn.GroupNorm(1, in_ch//2, affine=affineBN))
            layers.append(nn.ReLU(inplace=True))
        if int(out_ch//mult)==0:
            ch = 1
        else:
            ch =int(out_ch//mult)
        layers.append(nn.Conv2d(in_ch//2, ch, kernel_size=3,
                      stride=self.stride, padding=1, bias=False))
        layers.append(nn.GroupNorm(1, ch, affine=affineBN))
        layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv2d(ch, ch,
                      kernel_size=3, padding=1, bias=False))
        layers.append(nn.Dropout(p=dropout_rate))
        layers.append(nn.GroupNorm(1, ch, affine=affineBN))
        layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv2d(ch, out_ch, kernel_size=3,
                      padding=1, bias=False))
        self.bottleneck_block = nn.Sequential(*layers)

    def forward(self, x):
        """ bijective or injective block forward """
        x1 = x[0]
        x2 = x[1]
        Fx2 = self.bottleneck_block(x2)
        if self.stride == 2:
            x1 = self.psi.forward(x1)
            x2 = self.psi.forward(x2)
        y1 = Fx2 + x1
        return (x2, y1)

    def inverse(self, x):
        """ bijective or injecitve block inverse """
        x2, y1 = x[0], x[1]
        if self.stride == 2:
            x2 = self.psi.inverse(x2)
        Fx2 = - self.bottleneck_block(x2)
        x1 = Fx2 + y1
        if self.stride == 2:
            x1 = self.psi.inverse(x1)
        x = (x1, x2)
        return x




class autoencoder(nn.Module):
    def __init__(self, nBlocks, nStrides, nChannels=None, init_ds=2,
                 dropout_rate=0., affineBN=True, in_shape=None, mult=4,it=False):
        super(autoencoder, self).__init__()
        self.ds = in_shape[2]//2**(nStrides.count(2)+init_ds//2)
        self.init_ds = init_ds
        if init_ds == 1:
            self.in_ch = in_shape[0]
        else:
            self.in_ch = in_shape[0] * 2**self.init_ds
        self.nBlocks = nBlocks
        self.first = True
        self.it = it
        if not nChannels:
            nChannels = [self.in_ch//2, self.in_ch//2 * 4,
                         self.in_ch//2 * 4**2, self.in_ch//2 * 4**3]

        self.init_psi = psi(self.init_ds)
        self.stack = self.irevnet_stack(irevnet_block, nChannels, nBlocks,
                                        nStrides, dropout_rate=dropout_rate,
                                        affineBN=affineBN, in_ch=self.in_ch,
                                        mult=mult)

    def irevnet_stack(self, _block, nChannels, nBlocks, nStrides, dropout_rate,
                      affineBN, in_ch, mult):
        block_list = nn.ModuleList()
        strides = []
        channels = []
        for channel, depth, stride in zip(nChannels, nBlocks, nStrides):
            strides = strides + ([stride] + [1]*(depth-1))
            channels = channels + ([channel]*depth)
        for channel, stride in zip(channels, strides):
            block_list.append(_block(in_ch, channel, stride,
                                     first=self.first,
                                     dropout_rate=dropout_rate,
                                     affineBN=affineBN, mult=mult))
            in_ch = 2 * channel
            self.first = False
        return block_list

    def forward(self, input, is_predict = True):

        if is_predict:
            out = (self.init_psi.forward(input[:, :3, :, :]),self.init_psi.forward(input[:, 3:, :, :]))
            for block in self.stack:
                out = block.forward(out)
            x = out
        else:
            out = input
            for i in range(len(self.stack)):
                out = self.stack[-1 - i].inverse(out)
            x = merge(self.init_psi.inverse(out[0]),self.init_psi.inverse(out[1]))

        return x

class concept_slot(nn.Module):
    def __init__(self, input_size, output_size, slot_size = 15, len_obj = 17, len_verb = 4, upsample = False):
        super(concept_slot, self).__init__()
        self.input_size = input_size
        self.output_size = output_size
        self.slot_size = slot_size
        self.len_obj = len_obj
        self.len_verb = len_verb

        self.concept_layer_obj1 = nn.Sequential(nn.Conv2d(self.input_size, slot_size * len_obj, 3, 1, 1),
                                                nn.InstanceNorm2d(slot_size * len_obj, affine=True),
                                                nn.ReLU(),
                                                nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1))
        self.concept_layer_obj2 = nn.Sequential(nn.Conv2d(self.input_size, slot_size * len_obj, 3, 1, 1),
                                                nn.InstanceNorm2d(slot_size * len_obj, affine=True),
                                                nn.ReLU(),
                                                nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1))
        self.concept_layer_act = nn.Sequential(nn.Conv2d(self.input_size, slot_size * len_verb, 3, 1, 1),
                                                nn.InstanceNorm2d(slot_size * len_verb, affine=True),
                                                nn.ReLU(),
                                                nn.Conv2d(slot_size * len_verb, slot_size * len_verb, 3, 1, 1))
        if upsample:
            self.constituency_layer_obj1 = nn.Sequential(nn.ConvTranspose2d(slot_size * len_obj, slot_size * len_obj, 3, 2, 1),
                                                    nn.InstanceNorm2d(slot_size * len_obj, affine=True),
                                                    nn.ReLU(),
                                                    nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1))
            self.constituency_layer_obj2 = nn.Sequential(nn.ConvTranspose2d(slot_size * len_obj, slot_size * len_obj, 3, 2, 1),
                                                    nn.InstanceNorm2d(slot_size * len_obj, affine=True),
                                                    nn.ReLU(),
                                                    nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1))
            self.constituency_layer_act = nn.Sequential(nn.ConvTranspose2d(slot_size * len_verb, slot_size * len_verb, 3, 2, 1),
                                                   nn.InstanceNorm2d(slot_size * len_verb, affine=True),
                                                   nn.ReLU(),
                                                   nn.Conv2d(slot_size * len_verb, slot_size * len_verb, 3, 1, 1))
        else:
            self.constituency_layer_obj1 = nn.Sequential(nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1),
                                                         nn.InstanceNorm2d(slot_size * len_obj, affine=True),
                                                         nn.ReLU(),
                                                         nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1))
            self.constituency_layer_obj2 = nn.Sequential(nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1),
                                                         nn.InstanceNorm2d(slot_size * len_obj, affine=True),
                                                         nn.ReLU(),
                                                         nn.Conv2d(slot_size * len_obj, slot_size * len_obj, 3, 1, 1))
            self.constituency_layer_act = nn.Sequential(nn.Conv2d(slot_size * len_verb, slot_size * len_verb, 3, 1, 1),
                                                        nn.InstanceNorm2d(slot_size * len_verb, affine=True),
                                                        nn.ReLU(),
                                                        nn.Conv2d(slot_size * len_verb, slot_size * len_verb, 3, 1, 1))


    def forward(self, x, act, obj1, obj2):
        _,_, wh,_ = x.shape
        h_obj1 = self.constituency_layer_obj1(self.concept_layer_obj1(x) * obj1[:, :, None, None].repeat(1, self.slot_size, wh, wh))
        h_obj2 = self.constituency_layer_obj2(self.concept_layer_obj2(x) * obj2[:, :, None, None].repeat(1, self.slot_size, wh, wh))
        h_act = self.constituency_layer_act(self.concept_layer_act(x) * act[:, :, None, None].repeat(1, self.slot_size, wh, wh))

        return torch.cat((h_act,h_obj1,h_obj2),1)

